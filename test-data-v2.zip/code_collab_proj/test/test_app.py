"""Tests for the Flask task tracker (v2 - expanded)."""

import pytest
from app.main import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_list_empty(client):
    rv = client.get("/tasks")
    assert rv.status_code == 200
    assert rv.get_json() == []


def test_create_task(client):
    rv = client.post("/tasks", json={"title": "Write tests"})
    assert rv.status_code == 201
    data = rv.get_json()
    assert data["title"] == "Write tests"
    assert data["done"] is False


def test_update_task(client):
    client.post("/tasks", json={"title": "Do homework"})
    rv = client.put("/tasks/1", json={"done": True})
    assert rv.status_code == 200
    assert rv.get_json()["done"] is True


def test_delete_task(client):
    client.post("/tasks", json={"title": "Temp task"})
    rv = client.delete("/tasks/1")
    assert rv.status_code == 204


def test_delete_nonexistent(client):
    rv = client.delete("/tasks/999")
    assert rv.status_code == 404
