"""Tests for utility helpers."""

from app.utils import slugify, timestamp


def test_slugify():
    assert slugify("Hello World") == "hello-world"
    assert slugify("  Spaces  ") == "spaces"


def test_timestamp_format():
    ts = timestamp()
    assert "T" in ts  # ISO-8601 contains a T separator
