"""Utility helpers for the task tracker."""

from datetime import datetime


def timestamp() -> str:
    """Return an ISO-8601 timestamp string."""
    return datetime.now().isoformat()


def slugify(text: str) -> str:
    """Convert text to a URL-friendly slug."""
    return text.lower().strip().replace(" ", "-")
