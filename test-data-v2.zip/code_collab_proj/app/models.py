"""Data models for the task tracker (v2 - added timestamps)."""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Task:
    id: int
    title: str
    done: bool = False
    created_at: datetime = field(default_factory=datetime.now)

    def mark_done(self) -> None:
        self.done = True
