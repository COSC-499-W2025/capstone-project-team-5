# API Specification

## Endpoints

### GET /tasks
Returns a JSON array of all tasks.

### POST /tasks
Create a new task. Body: `{"title": "..."}`.
Returns the created task with `201`.

### PUT /tasks/<id>
Update an existing task. Body: `{"done": true}` or `{"title": "..."}`.

### DELETE /tasks/<id>
Delete a task by ID. Returns `204` on success, `404` if not found.
