# Changelog

## v2
- Added PUT /tasks/<id> endpoint for updating tasks
- Added DELETE /tasks/<id> endpoint for removing tasks
- Added utility module (utils.py) with timestamp and slugify helpers
- Expanded test suite with update, delete, and utility tests
- Models now include created_at timestamp

## v1
- Initial release with GET and POST endpoints
- Basic frontend listing tasks
