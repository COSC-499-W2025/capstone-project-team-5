# Task Tracker

A collaborative Flask + vanilla JS task tracker.

## Contributors
- Alice (backend API)
- Bob (frontend UI)
- Charlie (tests & CI)

## Running
```bash
pip install flask pytest
python app/main.py
```
