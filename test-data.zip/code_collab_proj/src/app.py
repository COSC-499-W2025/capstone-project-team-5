"""Flask web application – Task Tracker."""

from flask import Flask, jsonify, request

app = Flask(__name__)

tasks: list[dict] = []


@app.route("/tasks", methods=["GET"])
def list_tasks():
    return jsonify(tasks)


@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.get_json(force=True)
    task = {
        "id": len(tasks) + 1,
        "title": data.get("title", ""),
        "done": False,
    }
    tasks.append(task)
    return jsonify(task), 201


@app.route("/tasks/<int:task_id>", methods=["PUT"])
def update_task(task_id: int):
    task = next((t for t in tasks if t["id"] == task_id), None)
    if task is None:
        return jsonify({"error": "not found"}), 404
    data = request.get_json(force=True)
    task["done"] = data.get("done", task["done"])
    task["title"] = data.get("title", task["title"])
    return jsonify(task)


if __name__ == "__main__":
    app.run(debug=True)
