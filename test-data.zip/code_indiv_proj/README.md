# Personal Calculator

A simple calculator built in Python.

## Features
- Addition, subtraction, multiplication, division
- Command-line interface
