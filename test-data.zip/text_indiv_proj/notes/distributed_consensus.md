# Distributed Consensus

## Raft Algorithm
- Leader election via randomised timeouts
- Log replication through AppendEntries RPCs
- Safety guaranteed as long as majority is alive

## Paxos
- Single-decree and Multi-Paxos variants
- Proposers, acceptors, learners

## References
- Ongaro & Ousterhout, *In Search of an Understandable Consensus Algorithm*, 2014
