# CAP Theorem

You can only guarantee two of:
1. **Consistency** - every read receives the most recent write
2. **Availability** - every request receives a non-error response
3. **Partition tolerance** - the system keeps operating despite network splits

Most modern systems choose AP or CP.
