# Architecture

```
CSV  →  extract  →  transform  →  load  →  JSON
```

Each stage is a pure function for easy testing.
