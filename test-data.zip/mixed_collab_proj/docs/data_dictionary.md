# Data Dictionary

| Column | Type | Description |
|--------|------|-------------|
| id     | int  | Unique identifier |
| name   | str  | Participant name |
| score  | float | Raw test score (0–100) |
