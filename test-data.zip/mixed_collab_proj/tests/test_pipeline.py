"""Tests for the ETL pipeline."""

from pipeline.transform import normalise_scores


def test_normalise_scores():
    records = [{"score": "50"}, {"score": "100"}, {"score": "75"}]
    result = normalise_scores(records)
    assert result[0]["score"] == 0.0
    assert result[1]["score"] == 1.0
