"""Transform stage – clean and normalise data."""


def normalise_scores(records: list[dict], key: str = "score") -> list[dict]:
    scores = [float(r[key]) for r in records]
    lo, hi = min(scores), max(scores)
    span = hi - lo if hi != lo else 1
    for r in records:
        r[key] = round((float(r[key]) - lo) / span, 4)
    return records
