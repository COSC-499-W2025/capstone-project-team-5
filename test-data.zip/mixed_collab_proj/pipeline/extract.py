"""Extract stage – read CSV data."""

import csv
from pathlib import Path


def read_csv(path: Path) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))
