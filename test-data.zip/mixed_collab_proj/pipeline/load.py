"""Load stage – write results to JSON."""

import json
from pathlib import Path


def write_json(records: list[dict], dest: Path) -> None:
    dest.write_text(json.dumps(records, indent=2), encoding="utf-8")
