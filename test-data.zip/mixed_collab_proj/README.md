# Data Pipeline

Collaborative ETL pipeline with documentation.

## Team
- Dana (pipeline code)
- Eve (documentation & analysis)
