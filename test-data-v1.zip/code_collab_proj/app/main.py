"""Flask web application - Task Tracker (v1)."""

from flask import Flask, jsonify, request

app = Flask(__name__)

tasks: list[dict] = []


@app.route("/tasks", methods=["GET"])
def list_tasks():
    return jsonify(tasks)


@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.get_json(force=True)
    task = {
        "id": len(tasks) + 1,
        "title": data.get("title", ""),
        "done": False,
    }
    tasks.append(task)
    return jsonify(task), 201


if __name__ == "__main__":
    app.run(debug=True)
