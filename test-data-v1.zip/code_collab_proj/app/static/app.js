// Fetch and render tasks
async function loadTasks() {
  const res = await fetch("/tasks");
  const tasks = await res.json();
  const list = document.getElementById("task-list");
  list.innerHTML = "";
  tasks.forEach(t => {
    const li = document.createElement("li");
    li.textContent = t.title;
    list.appendChild(li);
  });
}

document.addEventListener("DOMContentLoaded", loadTasks);
