"""Tests for the Flask task tracker (v1)."""

import pytest
from app.main import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_list_empty(client):
    rv = client.get("/tasks")
    assert rv.status_code == 200
    assert rv.get_json() == []
