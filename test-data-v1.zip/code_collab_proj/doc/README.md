# Task Tracker

A collaborative Flask task tracker - early version.

## Contributors
- Alice (backend API)
- Bob (frontend UI)
- Charlie (tests)
